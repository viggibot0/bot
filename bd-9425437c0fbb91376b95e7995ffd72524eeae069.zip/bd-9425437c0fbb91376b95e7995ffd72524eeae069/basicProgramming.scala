

object basicProgramming {
  def main(args : Array[String])
  {
    println("Goodbye world")
    
  }   
      
  
}